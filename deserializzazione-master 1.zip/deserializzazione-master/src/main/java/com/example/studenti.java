package com.example;

public class studenti {
    int annoDiNascita;
    String cognome;
    String nome;

    public studenti() {
    }


    public int getAnnoDiNascita() {
        return this.annoDiNascita;
    }

    public void setAnnoDiNascita(int annoDiNascita) {
        this.annoDiNascita = annoDiNascita;
    }

    public String getCognome() {
        return this.cognome;
    }

    public void setCognome(String cognome) {
        this.cognome = cognome;
    }

    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
}
