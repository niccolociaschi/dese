package com.example;

public class aula {
    String nome;
    int nBanchi;

    public aula() {
    }


    public String getNome() {
        return this.nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getNumeroDiBanchi() {
        return this.nBanchi;
    }

    public void setNumeroDiBanchi(int nBanchi) {
        this.nBanchi = nBanchi;
    }
}
